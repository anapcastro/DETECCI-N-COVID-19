import random
import time

print("Piedra, Papel o Tijera")

listaDeObjetos= ["P", "PA", "T"]

puntosDelJugador=0
puntosCompu=0
i=1
Continuar=1
vecesAjugar=int(input("Cuantas veces quieres jugar? "))

while i <= vecesAjugar:
    selcompu= str(random.choice(listaDeObjetos))
    seljugador= raw_input("Escoje Piedra, Papel o Tijera (Usa: P, PA, T): ").upper()


    if (seljugador==selcompu):
        print ("Empate")

    elif (seljugador== "P"):
        print ("La computadora escogio: " +selcompu)
        if (selcompu=="PA"):
            print("Perdiste :(, el papel cubre a la piedra")
            puntosCompu= puntosCompu+1

        else:
            print("Ganaste! :), la piedra aplasta la tijera")
            puntosDelJugador= puntosDelJugador+1

    elif (seljugador=="PA"):
        print("La computadora escogio: " +selcompu)
        if (selcompu=="T"):
            print("Perdiste! :(, la tijera corta papel")
            puntosCompu= puntosCompu+1
        else:
            print("Ganaste! :), el papel cubre la piedra")
            puntosDelJugador= puntosDelJugador+1
            
    elif (seljugador=="T"):
        print("La computadora escogio: " +selcompu)
        if (selcompu=="P"):
            print("Perdiste! :(, la piedra aplasta la tijera")
            puntosCompu= puntosCompu+1
        else:
            print("Ganaste! :), la tijera corta el papel")
            puntosDelJugador= puntosDelJugador+1

    else:
        print ("Dato incorrecto. Juego no valido :(")

    print("Marcador\n")
    print("Tu: "+str(puntosDelJugador)+" Computadora: "+str(puntosCompu)+ "\n")
    print("Juego # "+str(i)+ "\n")
    
    i=i+1

print("Juego terminado.\n")

if (puntosDelJugador<puntosCompu):
    print("Perdiste la partida:(.\n La computadora gano con un marcador de: "+str(puntosCompu))
    time.sleep(15)
elif (puntosDelJugador==puntosCompu):
    print("Empate")
    time.sleep(15)
else:
    print("Ganaste!:), tu marcador es de: "+str(puntosDelJugador))
    time.sleep(15)

    

    
    
    

    
            
        
    

        
        
        
