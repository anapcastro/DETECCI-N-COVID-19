import turtle
import time
import random


posponer=0.1

#marcador
score=0
high_score=0


#ventana
ventanaS= turtle.Screen()
ventanaS.title("Juego Snake")
ventanaS.bgcolor("black")
ventanaS.setup(width=600, height=600)
ventanaS.tracer(0)

#cabeza serpiente
cabezaS=turtle.Turtle()
cabezaS.speed(0)
cabezaS.shape("square")
cabezaS.color("white")
cabezaS.penup()
cabezaS.goto(0,0)
cabezaS.direction="stop"

#comida
comidaS=turtle.Turtle()
comidaS.speed(0)
comidaS.shape("circle")
comidaS.color("red")
comidaS.penup()
comidaS.goto(0,100)


#cuerpo serpiente
segmentos=[]

#texto
texto= turtle.Turtle()
texto.speed(0)
texto.color("white")
texto.penup()
texto.hideturtle()
texto.goto(0, 260)
texto.write("Score: 0   High Score: 0", align="center", font=("Courier", 18, "normal"))

#funciones

def arriba():
    cabezaS.direction="up"
def abajo():
    cabezaS.direction="down"
def izq():
    cabezaS.direction="left"
def der():
    cabezaS.direction="right"

def mov():
    if (cabezaS.direction=="up"):
        y=cabezaS.ycor()
        cabezaS.sety(y + 20)
    if (cabezaS.direction=="down"):
        y=cabezaS.ycor()
        cabezaS.sety(y - 20)
    if (cabezaS.direction=="left"):
        x=cabezaS.xcor()
        cabezaS.setx(x - 20)
    if (cabezaS.direction=="right"):
        x=cabezaS.xcor()
        cabezaS.setx(x + 20)

#teclado
ventanaS.listen()
ventanaS.onkey(arriba, "Up")
ventanaS.onkey(abajo, "Down")
ventanaS.onkey(izq, "Left")
ventanaS.onkey(der, "Right")


while True:
    ventanaS.update()

    #colisiones bordes
    if ((cabezaS.xcor() > 280) or (cabezaS.xcor() < -280) or (cabezaS.ycor() > 280) or (cabezaS.ycor() < -280)):
        time.sleep(1)
        
        ventanaS.resetscreen()

        #ventana
        ventanaS= turtle.Screen()
        ventanaS.title("Juego Snake")
        ventanaS.bgcolor("black")
        ventanaS.setup(width=600, height=600)
        ventanaS.tracer(0)

        #cabeza serpiente
        cabezaS=turtle.Turtle()
        cabezaS.speed(0)
        cabezaS.shape("square")
        cabezaS.color("white")
        cabezaS.penup()
        cabezaS.goto(0,0)
        cabezaS.direction="stop"

        #comida
        comidaS=turtle.Turtle()
        comidaS.speed(0)
        comidaS.shape("circle")
        comidaS.color("red")
        comidaS.penup()
        comidaS.goto(0,100)


        #cuerpo serpiente
        segmentos=[]

        #texto
        texto= turtle.Turtle()
        texto.speed(0)
        texto.color("white")
        texto.penup()
        texto.hideturtle()
        texto.goto(0, 260)
        texto.write("Score: 0   High Score: 0", align="center", font=("Courier", 18, "normal"))


        #resetear
        score=0
        texto.clear()
        texto.write("Score: {}   High Score: {}".format(score, high_score), align="center", font=("Courier", 18, "normal"))

    if (cabezaS.distance(comidaS)< 20):
        x=random.randint(-280, 280)
        y=random.randint(-280, 280)
        comidaS.goto(x,y)

        segmentoN=turtle.Turtle()
        segmentoN.speed(0)
        segmentoN.shape("square")
        segmentoN.color("gray")
        segmentoN.penup()
        segmentos.append(segmentoN)

        score=score+10

        if ((score) > (high_score)):
            high_score=score
            
        texto.clear()
        texto.write("Score: {}   High Score: {}".format(score, high_score), align="center", font=("Courier", 18, "normal"))

        
#cola
    total_segmentos= len(segmentos)
    for index in range(total_segmentos -1, 0, -1):
        x=segmentos[index-1].xcor()
        y=segmentos[index-1].ycor()
        segmentos[index].goto(x,y)
    if ((total_segmentos) > 0):
        x= cabezaS.xcor()
        y= cabezaS.ycor()
        segmentos[0].goto(x,y)
    mov()
    #colisiones cuerpo
    for segmento in segmentos:
        if (segmento.distance(cabezaS)<20):
            time.sleep(1)
            
            ventanaS.resetscreen()

            #ventana
            ventanaS= turtle.Screen()
            ventanaS.title("Juego Snake")
            ventanaS.bgcolor("black")
            ventanaS.setup(width=600, height=600)
            ventanaS.tracer(0)

            #cabeza serpiente
            cabezaS=turtle.Turtle()
            cabezaS.speed(0)
            cabezaS.shape("square")
            cabezaS.color("white")
            cabezaS.penup()
            cabezaS.goto(0,0)
            cabezaS.direction="stop"

            #comida
            comidaS=turtle.Turtle()
            comidaS.speed(0)
            comidaS.shape("circle")
            comidaS.color("red")
            comidaS.penup()
            comidaS.goto(0,100)


            #cuerpo serpiente
            segmentos=[]

            #texto
            texto= turtle.Turtle()
            texto.speed(0)
            texto.color("white")
            texto.penup()
            texto.hideturtle()
            texto.goto(0, 260)
            texto.write("Score: 0   High Score: 0", align="center", font=("Courier", 18, "normal"))



          
            score=0
            texto.clear()
            texto.write("Score: {}   High Score: {}".format(score, high_score), align="center", font=("Courier", 18, "normal"))
    time.sleep(posponer)
ventanaS.mainloop()
