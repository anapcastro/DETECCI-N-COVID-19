# -- coding: cp1252 --
from Tkinter import *
import tkMessageBox
import Tkinter as Tk

usuarios=[]
contrasenas=[]
while True:
   
    puntos=["0"]
    puntos1=["0"]
    persona=["0"] #nombre
    nume=["0"] #numero de empleado

    def seleccionar():
        puntos.append("+1")
    ##    print(puntos)

 
    def aceptar():
        global FRE,ventanar,menuU, riesgo
        puntos1= ','.join(puntos)
        puntos2=puntos1.replace(",","")
        puntos3=puntos2.replace("'","")
        puntos4=puntos3.replace("[","")
        puntos5=puntos4.replace("]","")
        puntos6=puntos5.replace(" ","")
        FRE=eval(puntos6)
        #FRE=factores de riesgo espec�ficos
        if (FRE>=5):
            tkMessageBox.showinfo("ALTO RIESGO","Usted tiene un riesgo alto para el desarrollo de un cuadro grave cl�nico COVID-19")
            ventanar.destroy()
            menuU()
            riesgo="Alto riesgo"
        else:
            ventanar.destroy()
            menuU()
            riesgo="Bajo riesgo"

    def P1_2():
        BM['state']=DISABLED
        BH['state']=DISABLED
           
    def P1_1():
        global nombre, NE, NU, NC, Baceptar
        puntos.append("+1")
        P1_2()

    def bloq2():
        global B1,B2,B3,B4,B5
        B1['state']=DISABLED
        B2['state']=DISABLED
        B3['state']=DISABLED
        B4['state']=DISABLED
        B5['state']=DISABLED

    def P2_1():
        puntos.append("+1")
        bloq2()

    def P2_2():
        puntos.append("+2")
        bloq2()

    def P2_3():
        puntos.append("+3")
        bloq2()

    def P2_4():
        puntos.append("+4")
        bloq2()

    def P2_5():
        puntos.append("+5")
        bloq2()

    def P3_1():
        global nombre, NE, NU, NC, Baceptar,contrasenas,usuarios
        nombre=E1.get()
        NE=E2.get()
        NU=E3.get()
        NC=E4.get()

        if ((nombre=="") or (NE=="") or (NU=="") or (NC=="")):
            Baceptar['state']=DISABLED
            tkMessageBox.showinfo("ERROR","Introduzca los datos obligatorios.")
        else:
            Baceptar['state']=NORMAL
            E1['state']=DISABLED
            E2['state']=DISABLED
            E3['state']=DISABLED
            E4['state']=DISABLED
            B6['state']=DISABLED
            B7['state']=DISABLED
            B8['state']=DISABLED
            B9['state']=DISABLED
            if NU in usuarios:
                tkMessageBox.showinfo("ERROR","Usuario no disponible.")
                Baceptar['state']=DISABLED
                E1['state']=NORMAL
                E2['state']=NORMAL
                E3['state']=NORMAL
                E4['state']=NORMAL
                B6['state']=NORMAL
                B7['state']=NORMAL
                B8['state']=NORMAL
                B9['state']=NORMAL

            else:
                usuarios.append(NU)
                contrasenas.append(NC)
                print(usuarios)
                print(contrasenas)
                return(usuarios)
                return(contrasenas)

    def P3_2():
        puntos.append("+1")
        P3_1()

    def menuJ():
        global cp, cn, cneg
        ultima()
        ventanaJ=Tk.Tk()
        ventanaJ.geometry("300x180")
        ventanaJ.title("ESTADISTICAS EMPRESA")
        ventanaJ.iconbitmap("logo.ico")
        ventanaJ.config(bg="azure3")
        CP=str(cp)
        CN=str(cn)
        CNEG=str(cneg)
       

        La=Label(ventanaJ, text="Alta posibilidad: " +CP, font=("Times New Roman",12), bg="azure3") #va con entry 1
        La.place(x=90,y=15)

        Lb=Label(ventanaJ, text="Casos probables: " +CN, font=("Times New Roman",12), bg="azure3" ) #va con entry 1
        Lb.place(x=90,y=65)

        Lc=Label(ventanaJ, text="Baja posibilidad: " +CNEG, font=("Times New Roman",12), bg="azure3") #va con entry 1
        Lc.place(x=90,y=115)

    
       
    def login():
        global user,password,n,m,menuU,ventana2,usuarios,contrasenas
        user=Eusu.get()
        password=Econtra.get()
        if((user=="JEFE") and (password == "JEFE")):
            ventana2.destroy()
            menuJ()
        elif(user in usuarios):
            n=usuarios.index(user)
            m=contrasenas.index(password)
            if (n==m):
                ventana2.destroy()
                menuU()
            else:
                tkMessageBox.showinfo("Error","Contrase�a incorrecta")
        else:
            tkMessageBox.showinfo("Error","Usuario no encontrado")

    def registro():
        global LP, BH, BM,B1,B2,B3,B4,B5,E1,E2,E3,E4,B6,B7,B8,B9,Baceptar,ventanar,nombre,NE,NU,NC
        ventana2.destroy()
        ventanar=Tk.Tk()
        ventanar.geometry("400x680")
        ventanar.title("Factores de riesgo generales y espec�ficos")
        ventanar.config(bg="light blue")
        ventanar.iconbitmap("logo.ico")
        #Nombre y eso
        L0=Label(ventanar, text="Por favor, introduzca sus datos (*campos obligatorios):", bg="light blue") #va con entry 1
        L0.place(x=15,y=10)
        L1=Label(ventanar, text="*Nombre completo", bg="light blue" ) #va con entry 1
        L1.place(x=15,y=30)
        E1=Entry(ventanar)
        E1.place(x=15,y=50)
        nombre=E1.get() ##
        L2=Label(ventanar, text="*Numero de empleado", bg="light blue")
        L2.place(x=15,y=70)
        E2=Entry(ventanar)
        E2.place(x=15,y=90)
        NE=E2.get() ##
        L3=Label(ventanar, text="*Introduzca su nuevo usuario", bg="light blue")
        L3.place(x=15,y=110)
        E3=Entry(ventanar)
        E3.place(x=15,y=130)
        NU=E3.get() ##
        L4=Label(ventanar,text="*Introduzca su nueva contrasenia", bg="light blue")
        L4.place(x=15,y=150)
        E4=Entry(ventanar)
        E4.place(x=15,y=170)
        NC=E4.get() ##
        #Pregunta 1
        LP=Label(ventanar, text="1. Sexo biologico",bg="light blue")
        LP.place(x=15,y=200)
        BH=Button(ventanar, text="Hombre", command=P1_1)
        BH.place(x=15,y=225)
        BM=Button(ventanar, text="Mujer", command=P1_2)
        BM.place(x=75,y=225)
        #Pregunta 2
        LP=Label(ventanar, text="2. Edad",bg="light blue")
        LP.place(x=15,y=255)
        B1=Button(ventanar, text="20-30", command=P2_1)
        B1.place(x=15,y=280)
        B2=Button(ventanar, text="31-40", command=P2_2)
        B2.place(x=65,y=280)
        B3=Button(ventanar, text="41-50", command=P2_3)
        B3.place(x=115,y=280)
        B4=Button(ventanar, text="51-60", command=P2_4)
        B4.place(x=165,y=280)
        B5=Button(ventanar, text="+60", command=P2_5)
        B5.place(x=215,y=280)
        #Pregunta 3
        LP=Label(ventanar, text="3. Peso",bg="light blue")
        LP.place(x=15,y=310)
        B6=Button(ventanar, text="Peso bajo", command=P3_1)
        B6.place(x=15,y=335)
        B7=Button(ventanar, text="Peso normal", command=P3_1)
        B7.place(x=85,y=335)
        B8=Button(ventanar, text="Sobrepeso", command=P3_2)
        B8.place(x=170,y=335)
        B9=Button(ventanar, text="Obesidad", command=P3_2)
        B9.place(x=245,y=335)
        Baceptar=Button(ventanar, text="Aceptar", command=aceptar)
        Baceptar.place(x=280,y=640)
        Baceptar['state']=DISABLED
        #factores de riesgo espec�ficos
        dbts= IntVar()
        fmcs= IntVar()
        emb=IntVar()
        cardio=IntVar()
        hepcr=IntVar()
        pulcr=IntVar()
        rencr=IntVar()
        neurocr=IntVar()
        inmudef=IntVar()
        cancer=IntVar()
        L=Label(ventanar, text="4. Factores de riesgo especificos", bg="light blue")
        L.place(x=15,y=370)
        chk1=Checkbutton(ventanar, text="Diabetes", variable=dbts,onvalue=1, offvalue=0, command=seleccionar, bg="light blue")
        chk1.place(x=15,y=395)
        chk2=Checkbutton(ventanar, text="Tratamiento con farmacos que producen inmunosupresion", variable=fmcs,onvalue=1, offvalue=0, command=seleccionar, bg="light blue") #command=algo)
        chk2.place(x=15,y=420)
        chk3=Checkbutton(ventanar, text="Embarazada o postparto", variable=emb,onvalue=1, offvalue=0, command=seleccionar, bg="light blue") #command=algo)
        chk3.place(x=15,y=445)
        chk4=Checkbutton(ventanar, text="Enfermedad cardiovascular(hipertension)", variable=cardio,onvalue=1, offvalue=0, command=seleccionar, bg="light blue") #command=algo)
        chk4.place(x=15,y=470)
        chk5=Checkbutton(ventanar, text="Enfermedad hepatica cronica", variable=hepcr,onvalue=1, offvalue=0, command=seleccionar,bg="light blue") #command=algo)
        chk5.place(x=15,y=495)
        chk6=Checkbutton(ventanar, text="Enfermedad pulmonar cronica", variable=pulcr,onvalue=1, offvalue=0, command=seleccionar, bg="light blue") #command=algo)
        chk6.place(x=15,y=520)
        chk7=Checkbutton(ventanar, text="Enfermedad renal cronica", variable=rencr,onvalue=1, offvalue=0,command=seleccionar,bg="light blue") #command=algo)
        chk7.place(x=15,y=545)
        chk8=Checkbutton(ventanar, text="Enfermedad neurologica o neuromuscular cronica", variable=neurocr,onvalue=1, offvalue=0,command=seleccionar, bg="light blue") #command=algo)
        chk8.place(x=15,y=570)
        chk9=Checkbutton(ventanar, text="Inmunodeficiencia congenita o adquirida (incluyendo el VIH)", variable=inmudef,onvalue=1, offvalue=0,command=seleccionar, bg="light blue") #command=algo)
        chk9.place(x=15,y=595)
        chk10=Checkbutton(ventanar, text="Cancer", variable=cancer,onvalue=1, offvalue=0,command=seleccionar, bg="light blue") #command=algo)
        chk10.place(x=15,y=620)    
        #ventanar.destroy()

    def Ebloq1():
        global b1,b2,b200
        b1['state']=DISABLED
        b2['state']=DISABLED
        b200['state']=DISABLED
       
    def E1_1():
        puntos1.append("+4")
        Ebloq1()
       
    def E1_2():
        puntos1.append("+5")
        Ebloq1()

    def E1_3():
        Ebloq1()

    def E2_2():
        global b3,b4
        b3['state']=DISABLED
        b4['state']=DISABLED
       
    def E2_1():
        puntos1.append("+3")
        E2_2()
       
    def E3_2():
        global b5,b6
        b5['state']=DISABLED
        b6['state']=DISABLED
       
    def E3_1():
        puntos1.append("+2")
        E3_2()
       
    def E4_2():
        global b7,b8
        b7['state']=DISABLED
        b8['state']=DISABLED
       
    def E4_1():
        puntos1.append("+5")
        E4_2()
       
    def E5_2():
        global b9,b10,b15
        b9['state']=DISABLED
        b10['state']=DISABLED
        b15['state']=NORMAL
        checkpoint()
       
    def E5_1():
        puntos1.append("+5")
        E5_2()

    def checkpoint():
        global salud
        x=" ".join(puntos1)
        resultado=eval(x)
        if (resultado==4):
            tkMessageBox.showinfo("Resultado","Este test no reemplaza un examen de detecci�n, pero es importante que acudas lo antes posible a un centro de salud con las medidas necesarias para protegerte a ti mismo y aquienes te rodean.")
            tkMessageBox.showinfo("Resultado","NO ES CASO PROBABLE DE COVID-19. ")
            salud="Baja posibilidad"
                   
    def Seleccionar():
        puntos1.append("+1")
        print(puntos1)
       
    def dificultad():
        puntos1.append("+1")
        b11['state']=NORMAL
        b12['state']=NORMAL
       
    def enfermedad():
        global b13,b14
        b11['state']=DISABLED
        b12['state']=DISABLED
        b13['state']=NORMAL
        b14['state']=NORMAL
       
    def probable():
        b13['state']=DISABLED
        b14['state']=DISABLED

    def memorama():
        import os
        os.system('python memo.py')
        
    def vb():
        import os
        os.system('python JUEGOS.py')

    def ah():
        import os
        os.system('python ahorcadop.py')
        
    def ppt():
        import os
        os.system('python PPT.py')

    def mm():
        import os
        os.system('python MasterMind.py')
        
    def alta():
        ventanaJuego=Tk.Tk()
        ventanaJuego.title("Juegos")
        ventanaJuego.geometry("300x180")
        ventanaJuego.iconbitmap("jueguito.ico")
        ventanaJuego.config(bg="blue2")

        B1J=Button(ventanaJuego,text="Memorama",command=memorama, font="System")
        B1J.place(x=15, y=15)
        B2J=Button(ventanaJuego,text="   Viborita    ",command=vb, font="System")
        B2J.place(x=120, y=15)
        B3J=Button(ventanaJuego,text=" Ahorcado  ",command=ah, font="System")
        B3J.place(x=15, y=60)
        B4J=Button(ventanaJuego,text=" Piedra, papel o tijera           ",command=ppt, font="System")
        B4J.place(x=15, y=100)
        B5J=Button(ventanaJuego,text="MasterMind",command=mm, font="System")
        B5J.place(x=120, y=60)
        

    def suma(): #finalizar
        global salud, NE, nombre, riesgo, anio, mes, dia, cp, cneg, cn
        dia=Sp1.get()
        mes=Sp2.get()
        anio=Sp3.get()
        x=" ".join(puntos1)
        resultado=eval(x)
        if((resultado>=5)and (resultado<10)):
            tkMessageBox.showinfo("Resultado","Este test no reemplaza un examen de detecci�n, pero es importante que acudas lo antes posible a un centro de salud con las medidas necesarias para protegerte a ti mismo y aquienes te rodean.")
            tkMessageBox.showinfo("Resultado","CASO PROBABLE DE COVID-19. ")
            salud="Caso probable"          
           
        elif(resultado>=10):
            tkMessageBox.showinfo("Resultado","Este test no reemplaza un examen de detecci�n, pero es importante que acudas lo antes posible a un centro de salud con las medidas necesarias para protegerte a ti mismo y aquienes te rodean.")
            tkMessageBox.showinfo("Resultado","EXISTE UNA ALTA POSIBILIDAD DE QUE HAYAS CONTRAIDO COVID-19. \n ")
            salud="Alta posibilidad"
            alta()
        b13['state']=DISABLED
        b14['state']=DISABLED
        Sp1['state']=DISABLED
        Sp2['state']=DISABLED
        Sp3['state']=DISABLED
       
        f=open("Registro.txt","a")
       
        f.write("Fecha: ")
        f.write(dia+ " " + mes+" " +anio +'\n')
        f.write("Empleado: ")
        f.write(nombre + '\n')
        f.write("Numero de empleado: ")
        f.write(NE + '\n')
        f.write("Riesgo: ")
        f.write(riesgo + '\n')
        f.write("Salud actual: " )
        f.write(salud + '\n')
        f.write('\n')
        f.close()
        ultima()

        ventanaU.destroy()
    def ultima():
        global salud, NE, nombre, riesgo, anio, mes, dia, cp, cneg, cn
        cn=0
        cp=0
        cneg=0

        f=open("Registro.txt","r")
        for linea in f:
            linea.rstrip()
            if  ((linea.startswith("Salud actual: Alta")) or (linea.startswith("Salud actual: Caso")) or (linea.startswith("Salud actual: Baja"))):
                if linea.startswith("Salud actual: Alta"):
                    cp=cp+1
                       

                if linea.startswith ("Salud actual: Caso"):
                    cn=cn+1
                       
                if linea.startswith ("Salud actual: Baja"):
                    cneg=cneg+1
                       
            else:
                continue
               
        print(cp)
        print(cn)
        print(cneg)


       

    def menuU():
        global b1, b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,ventanaU,b15, dia,mes,anio, Sp1, Sp2, Sp3,b200
        ventanaU=Tk.Tk()
        ventanaU.geometry("850x600")
        ventanaU.title("Encuesta diaria COVID-19")
        ventanaU.iconbitmap("logo.ico")
        ventanaU.config(bg="SlateGray1")
        #Pregunta 1 temperatura
        L_1=Label(ventanaU, text="1. Temperatura corporal", bg="SlateGray1")
        L_1.place(x=15,y=25)
        b1=Button(ventanaU, text="37.5-38.5", command=E1_1)
        b1.place(x=80,y=50)
        b2=Button(ventanaU, text="   >=39   ", command=E1_2)
        b2.place(x=145,y=50)
        b200=Button(ventanaU, text="   <37.5   ", command=E1_3)
        b200.place(x=15,y=50)
        #Pregunta 2 tos
        L_2=Label(ventanaU, text="2. Tos continuada o persistente", bg="SlateGray1")
        L_2.place(x=15,y=85)
        b3=Button(ventanaU, text="  Si  ", command=E2_1)
        b3.place(x=15,y=110)
        b4=Button(ventanaU, text=" No ", command=E2_2)
        b4.place(x=55,y=110)
        #Pregunta 3 Dolor de cabeza
        L_3=Label(ventanaU, text="3. Dolor de cabeza", bg="SlateGray1")
        L_3.place(x=15,y=145)
        b5=Button(ventanaU, text="  Si  ", command=E3_1)
        b5.place(x=15,y=170)
        b6=Button(ventanaU, text=" No ", command=E3_2)
        b6.place(x=55,y=170)
        #Pregunta 4 Perdida de gusto
        L_4=Label(ventanaU, text="4.Perdida de gusto", bg="SlateGray1")
        L_4.place(x=15,y=205)
        b7=Button(ventanaU, text="  Si  ", command=E4_1)
        b7.place(x=15,y=230)
        b8=Button(ventanaU, text=" No ", command=E4_2)
        b8.place(x=55,y=230)
        #Pregunta 5 Perdida de olfato
        L_5=Label(ventanaU, text="5. Perdida de olfato",bg="SlateGray1")
        L_5.place(x=15,y=265)
        b9=Button(ventanaU, text="  Si  ", command=E5_1)
        b9.place(x=15,y=290)
        b10=Button(ventanaU, text=" No ", command=E5_2)
        b10.place(x=55,y=290)
        #Pregunta 6
        L_6=Label(ventanaU, text="6. Marcar las casillas de los sintomas que presente",bg="SlateGray1")
        L_6.place(x=15,y=330)
        garga=IntVar()
        nasa=IntVar()
        ojo=IntVar()
        arti=IntVar()
        hemo=IntVar()
        docost=IntVar()
        dia=IntVar()
        vomi=IntVar()
        escalo=IntVar()
        doab=IntVar()
        domu=IntVar()
        doarti=IntVar()
        debil=IntVar()
        doali=IntVar()
        conjun=IntVar()
        difirespi=IntVar()
        Chk1=Checkbutton(ventanaU, text="Dolor o ardor de garganta", variable=garga, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk1.place(x=15, y=350)
        Chk2=Checkbutton(ventanaU, text="Escurrimiento nasal", variable=nasa, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk2.place(x=15, y=370)
        Chk3=Checkbutton(ventanaU, text="Ojos rojos", variable=ojo, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk3.place(x=15, y=390)
        Chk4=Checkbutton(ventanaU, text="Dolores en musculos y articulaciones", variable=arti, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk4.place(x=15, y=410)
        Chk5=Checkbutton(ventanaU, text="Hemoptisis (expectorar sangre)", variable=hemo, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk5.place(x=15, y=430)
        Chk6=Checkbutton(ventanaU, text="Dolor en el costado", variable=docost, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk6.place(x=15, y=450)
        Chk7=Checkbutton(ventanaU, text="Diarrea", variable=dia, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk7.place(x=15, y=470)
        Chk8=Checkbutton(ventanaU, text="Vomito", variable=vomi, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk8.place(x=15, y=490)
        Chk9=Checkbutton(ventanaU, text="Calosfrios (escalofrios)", variable=escalo, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk9.place(x=350, y=350)
        Chk10=Checkbutton(ventanaU, text="Dolor abdominal", variable=doab, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk10.place(x=350, y=370)
        Chk11=Checkbutton(ventanaU, text="Dolor muscular", variable=domu, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk11.place(x=350, y=390)
        Chk12=Checkbutton(ventanaU, text="Dolor en las articulaciones", variable=doarti, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk12.place(x=350, y=410)
        Chk13=Checkbutton(ventanaU, text="Debilidad y malestar general", variable=debil, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk13.place(x=350, y=430)
        Chk14=Checkbutton(ventanaU, text="Dolor en la garganta al tragar alimentos", variable=doali, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk14.place(x=350, y=450)
        Chk15=Checkbutton(ventanaU, text="Conjuntivitis", variable=conjun, onvalue=1, offvalue=0, command=Seleccionar,bg="SlateGray1")
        Chk15.place(x=350, y=470)
        Chk16=Checkbutton(ventanaU, text="Dificultad respiratoria", variable=difirespi, onvalue=1, offvalue=0, command=dificultad,bg="SlateGray1")
        Chk16.place(x=350, y=490)
        #Pregunta 7 Perdida de olfato
        L_7=Label(ventanaU, text="7. En que situacion se presenta esta dificultad?",bg="SlateGray1")
        L_7.place(x=350,y=35)
        b11=Button(ventanaU, text="Tengo sensacion de ahogo con peque�os esfuerzos (levantarme, agacharme)", command=enfermedad)
        b11.place(x=350,y=60)
        b12=Button(ventanaU, text="Tengo sensacion de ahogo en reposo", command=enfermedad)
        b12.place(x=350,y=90)
        b11['state']=DISABLED
        b12['state']=DISABLED
        L_8=Label(ventanaU, text="8. Padece alguna enfermedad que pueda ocasionar esta situacion(asma,EPOC, etc.)?",bg="SlateGray1")
        L_8.place(x=350,y=130)
        b13=Button(ventanaU, text="  Si  ", command=probable)
        b13.place(x=350,y=150)
        b14=Button(ventanaU, text=" No ", command=probable)
        b14.place(x=390,y=150)
        b13['state']=DISABLED
        b14['state']=DISABLED
        b15=Button(ventanaU, text="Finalizar", command=suma)
        b15['state']=DISABLED
        b15.place(x=600,y=530)
        #spinbox
        L_9=Label(ventanaU, text="9. Fecha",bg="SlateGray1")
        L_9.place(x=350,y=200)
        x=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"]
        Sp1=Spinbox(ventanaU, values=x)# command=Color_bg)
        Sp1.place(x=350, y =225)
        #dia=Sp1.get()
        y=["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio", "Agosto", "Septiembre","Octubre","Noviembre","Diciembre"]
        Sp2=Spinbox(ventanaU, values=y)#, command=Color_bg)
        Sp2.place(x=490, y =225)
        #mes=Sp2.get()
        z=["2020", "2021"]
        Sp3=Spinbox(ventanaU, values=z)#, command=Color_bg)
        Sp3.place(x=630, y =225)
        #anio=Sp3.get()
       
    def todo():
        global ventana2
    
        ventana2=Tk.Tk()
        ventana2.geometry("200x200")
        ventana2.title("Datos")
        ventana2.config(bg="LightSkyBlue1")
        ventana2.iconbitmap("logo.ico")
        global Eusu, Econtra
        Lusu=Label(ventana2, text="Usuario", bg="LightSkyBlue1", font=("Times New Roman",10))
        Lusu.place(x=10,y=10)
        Lcontra=Label(ventana2, text="Contra",bg="LightSkyBlue1",font=("Times New Roman",10))
        Lcontra.place(x=10,y=50)
        Eusu=Entry(ventana2)
        Eusu.place(x=10,y=30)
        Econtra=Entry(ventana2,show="*")
        Econtra.place(x=10,y=70)
        Bacept=Button(ventana2, text="Ingresar", command=login, font=("Times New Roman",10))
        Bacept.place(x=5,y=100)
        Breg=Button(ventana2, text="Registrarse", command=registro,font=("Times New Roman",10))
        Breg.place(x=65,y=100)

    todo()

    ventana2.mainloop()
