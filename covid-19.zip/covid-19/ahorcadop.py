from Tkinter import*
import tkMessageBox
from random import randint
##from PIL import ImageTk

letrasU=[]

vidas=7
letrasA=0
def CL():
    x=50
    y=150
    contador=0
    Label(canvas, text="Letras sin usar", font=("Arial",15)).place(x=50, y=100)
    for i in range(26):
        contador=contador+1
        LL[i].place(x=x,y=y)
        x=x+30
        if contador==5:
            y=y+35
            contador=0
            x=50
    

def ProbarL():
    global vidas
    global letrasA
    letrasU.append(letrao.get())
    print(letrasU)
    LL[ord(letrao.get())-97].config(text="")
    if letrao.get() in Palabra:
        if Palabra.count(letrao.get())>1:
            letrasA=letrasA + Palabra.count(letrao.get())
            for i in range(len(Palabra)):
                if Palabra[i]==letrao.get():
                    G[i].config(text=""+letrao.get())
        else:
            letrasA=letrasA + 1
            G[Palabra.index(letrao.get())].config(text=""+letrao.get())
        if letrasA== len(Palabra):
            tkMessageBox.showinfo("Victoria","Felicidades has ganado")
                        
    else:
        vidas=vidas-1
        canvas.itemconfig(imagen_id, image=imagenes[vidas-1])
        if vidas==0:
            tkMessageBox.showinfo("Game Over","Se te han acabado las vidas")
        
                

ventana=Tk()
archivo= open("palabras.txt", "r")
CP=list(archivo.read().split("\n"))
Palabra=CP[randint(0,len(CP)-1)].lower()
letrao=StringVar()

ventana.config(width=1000, height=600,background="azure",relief="groove",bd=10)
ventana.geometry("1000x600")
canvas=Canvas(ventana, width=1000, height=600)
canvas.pack(expand=True, fill="both")
imagenes=[
    PhotoImage(file="1A.gif"),
    PhotoImage(file="2A.gif"),
    PhotoImage(file="3A.gif"),
    PhotoImage(file="4A.gif"),
    PhotoImage(file="5A.gif"),
    PhotoImage(file="6A.gif"),
    PhotoImage(file="7A.gif"),
]
imagen_id=canvas.create_image(750,300, image=imagenes[6])

Label(canvas,text="Introduce una letra", font=("Arial",20)
      ).grid(row=0,column=0,padx=10,pady=10)
L=Entry(canvas, width=2, font=("Arial",20),textvariable=letrao
        ).grid(row=0,column=1,padx=10,pady=10)
PL=Button(canvas, text="Probar", bg="azure", font=("Arial",15),command=ProbarL
          ).grid(row=1,column=0,pady=2)
LL=[Label(canvas, text=chr(j+97),font=("Arial",15)) for j in range(26)]
CL()
G=[Label(canvas,text="_",font=("Arial",20)) for _ in Palabra]
inicialX=200
for i in range(len(Palabra)):
    G[i].place(x=inicialX, y=400)
    inicialX=inicialX+50

ventana.mainloop()
